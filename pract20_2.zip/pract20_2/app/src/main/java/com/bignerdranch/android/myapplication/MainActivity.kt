package com.bignerdranch.android.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import com.bignerdranch.android.myapplication.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    private lateinit var button0: Button
    private lateinit var button1: Button
    private lateinit var button2: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        //val navController = findNavController(R.id.nav_host_fragment_content_main)
        //appBarConfiguration = AppBarConfiguration(navController.graph)
        //setupActionBarWithNavController(navController, appBarConfiguration)


    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
    fun onClick1(view: View) {
        var snackbar= Snackbar.make(view,"Prologistic.com.ua - программирование на Java | Android",
            Snackbar.LENGTH_LONG)
        snackbar.show()
    }
    fun onClick2(view: View) {
        var snackbar= Snackbar.make(view,"Вы изменили что-то", Snackbar.LENGTH_LONG)
        snackbar.setAction("ВЕРНУТЬ КАК БЫЛО?", View.OnClickListener{
            snackbar= Snackbar.make(view,"Все вернулось на свои места!", Snackbar.LENGTH_LONG)
            snackbar.show()
        })

        snackbar.show()
    }
    fun onClick3(view: View) {
        var snackbar= Snackbar.make(view,"Повторите еще раз!", Snackbar.LENGTH_LONG)
        snackbar.setAction("ПОВТОРИТЕ", View.OnClickListener{

        })
        snackbar.show()
    }
}
